import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ContentionicPageRoutingModule } from './contentionic-routing.module';

import { ContentionicPage } from './contentionic.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ContentionicPageRoutingModule
  ],
  declarations: [ContentionicPage]
})
export class ContentionicPageModule {}
