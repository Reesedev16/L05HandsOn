import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contentionic',
  templateUrl: './contentionic.page.html',
  styleUrls: ['./contentionic.page.scss'],
})
export class ContentionicPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
