import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { ContentionicPage } from './contentionic.page';

describe('ContentionicPage', () => {
  let component: ContentionicPage;
  let fixture: ComponentFixture<ContentionicPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ContentionicPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
