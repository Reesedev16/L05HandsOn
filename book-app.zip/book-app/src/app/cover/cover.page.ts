import { Component, NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-cover',
  templateUrl: 'cover.page.html',
  styleUrls: ['cover.page.scss'],
})
export class CoverPage {
goToTOC: any;
  constructor() {}
}

@NgModule({
  imports: [
    IonicModule.forRoot()
  ],
  declarations: [CoverPage]
})
export class CoverPageModule {}