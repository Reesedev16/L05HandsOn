import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CoverPage } from './cover/cover.page';
import { TOCPage } from './toc/toc.page';
import { ContentPage } from './content/content.page';

const routes: Routes = [
  { path: 'cover', component: CoverPage },
  { path: 'toc', component: TOCPage },
  { path: 'content/:pageNumber', component: ContentPage },
  { path: '', redirectTo: 'cover', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}