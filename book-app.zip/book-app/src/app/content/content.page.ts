import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-content',
  templateUrl: './content.page.html',
  styleUrls: ['./content.page.scss'],
})
export class ContentPage {
  chapter = {
    chapterTitle: '',
    content: '',
    image: '',
    pageNumber: null as number | null,
    nextContentPage: null as number | null,
    previousContentPage: null as number | null
  };
previousContentPage: any;
nextContentPage: any;

  constructor(
    private navCtrl: NavController,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      const pageNumber = parseInt(params['pageNumber'], 10);

      switch (pageNumber) {
        case 1:
          this.chapter = {
            chapterTitle: 'Chapter 1: The Discovery',
            content: 'Once upon a time, in a small town, there was a curious four-year-old boy named Isaiah. One sunny day, while playing in his backyard, he stumbled upon a rare fruit hidden among the bushes. It was unlike any fruit he had ever seen before – it was shiny and had a bright purple color.',
            image: 'https://via.placeholder.com/500x300',
            pageNumber: 1,
            nextContentPage: 2,
            previousContentPage: null
          };
          break;

        case 2:
          this.chapter = {
            chapterTitle: 'Chapter 2: The Superpowers',
            content: 'As Isaiah took a bite of the fruit, he felt a sudden surge of energy coursing through his veins. To his amazement, he discovered that he had obtained incredible superpowers. He had the ability to fly, to lift heavy objects, and to shoot laser beams from his eyes.',
            image: 'https://via.placeholder.com/500x300',
            pageNumber: 2,
            nextContentPage: 3,
            previousContentPage: 1
          };
          break;

        case 3:
          this.chapter = {
            chapterTitle: 'Chapter 3: The Villain',
            content: 'As Isaiah practiced his powers, he noticed that a stranger had moved in next door. The stranger was a grumpy old man who always yelled at kids for playing too loudly. One day, as Isaiah was playing in his backyard, the old man came up to the fence and started yelling at him. Isaiah asked him to stop, but the old man wouldn\'t listen. He started throwing rocks and sticks at Isaiah.',
            image: 'https://via.placeholder.com/500x300',
            pageNumber: 3,
            nextContentPage: null,
            previousContentPage: 2
          };
          break;

        default:
          this.chapter = {
            chapterTitle: 'Chapter Not Found',
            content: 'Sorry, the chapter you requested could not be found.',
            image: '',
            pageNumber: null,
            nextContentPage: null,
            previousContentPage: null
          };
          break;
      }
    });
  }

  goToTOC() {
    this.navCtrl.navigateForward('/toc');
  }

  goToNextPage() {
    if (this.chapter.nextContentPage !== null) {
      this.navCtrl.navigateForward(`/content/${this.chapter.nextContentPage}`);
    }
  }

  goToPreviousPage() {
    if (this.chapter.previousContentPage !== null) {
      this.navCtrl.navigateForward(`/content/${this.chapter.previousContentPage}`);
    }
  }
}
