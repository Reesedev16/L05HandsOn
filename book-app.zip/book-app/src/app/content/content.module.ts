import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';

import { ContentPage } from './content.page';


@NgModule({
  imports: [
    CommonModule,
    IonicModule,

  ],
    
  declarations: [
    ContentPage
  ]
})
export class ContentPageModule {}