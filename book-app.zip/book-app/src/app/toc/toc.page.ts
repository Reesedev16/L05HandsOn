import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { IonicModule } from '@ionic/angular';
@Component({
  selector: 'app-toc',
  templateUrl: './toc.page.html',
  styleUrls: ['./toc.page.scss'],
})
export class TOCPage {
  chapter1 = {
    chapterTitle: 'Chapter 1: The Discovery',
    content: 'Once upon a time, in a small town, there was a curious four-year-old boy named Isaiah. One sunny day, while playing in his backyard, he stumbled upon a rare fruit hidden among the bushes. It was unlike any fruit he had ever seen before – it was shiny and had a bright purple color.',
    image: 'https://via.placeholder.com/500x300', // Placeholder image URL
    pageNumber: 1,
    nextContentPage: 2,
    previousContentPage: null
  };

  chapter2 = {
    chapterTitle: 'Chapter 2: The Superpowers',
    content: 'As Isaiah took a bite of the fruit, he felt a sudden surge of energy coursing through his veins. To his amazement, he discovered that he had obtained incredible superpowers. He had the ability to fly, to lift heavy objects, and to shoot laser beams from his eyes.',
    image: 'https://via.placeholder.com/500x300', // Placeholder image URL
    pageNumber: 2,
    nextContentPage: 3,
    previousContentPage: 1
  };

  chapter3 = {
    chapterTitle: 'Chapter 3: The Villain',
    content: 'As Isaiah practiced his powers, he noticed that a stranger had moved in next door. The stranger was a grumpy old man who always yelled at kids for playing too loudly. One day, as Isaiah was playing in his backyard, the old man came up to the fence and started yelling at him. Isaiah asked him to stop, but the old man wouldn\'t listen. He started throwing rocks and sticks at Isaiah.',
    image: 'https://via.placeholder.com/500x300', // Placeholder image URL
    pageNumber: 3,
    nextContentPage: null,
    previousContentPage: 2
  };

  constructor(private navCtrl: NavController) {}

  goToContentPage(page: { pageNumber: any; }) {
    this.navCtrl.navigateForward(`/content/${page.pageNumber}`);
  }

  goToCoverPage() {
    this.navCtrl.navigateBack('/cover');
  }
}