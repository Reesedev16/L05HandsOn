import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { TOCPage } from './toc.page';

@NgModule({
  imports: [
    CommonModule,
    IonicModule
  ],
  declarations: [
    TOCPage
  ],
  exports: [
    TOCPage
  ]
})
export class TOCPageModule {}