import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { TOCPage } from './toc.page';

describe('TocPage', () => {
  let component: TOCPage;
  let fixture: ComponentFixture<TOCPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(TOCPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
